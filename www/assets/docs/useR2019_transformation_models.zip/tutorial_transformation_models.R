## ----setup, echo = FALSE, results='hide', message = FALSE----------------
set.seed(290875)

### these packages are needed
chk <- sapply(pkgs <- c("colorspace", "multcomp", "survival", "lattice", 
                        "latticeExtra", "MASS", "sandwich", "TH.data",
                        "coin", "interval", "mboost", "tram", "trtf", "tbm"), 
              function(x) 
                  require(x, quietly = TRUE, 
                          character.only = TRUE))
stopifnot(all(chk))
### tram 0.2-6 or later is needed
stopifnot(compareVersion(packageDescription("tram")$Version, 
                         "0.2-6") >= 0)

tcols <- diverge_hcl(50, h = c(246, 40), c = 96, l = c(65, 90))
cols <- tcols[c(1, length(tcols))]
trellis.par.set(list(plot.symbol = list(col=1,pch=20, cex=0.7),
                     box.rectangle = list(col=1),
                     box.umbrella = list(lty=1, col=1),
                     strip.background = list(col = "white")))
ltheme <- canonical.theme(color = FALSE)     ## in-built B&W theme
ltheme$strip.background$col <- "transparent" ## change strip bg
lattice.options(default.theme = ltheme)
order <- 6


## ----SGB-data, echo = FALSE, results = "hide"----------------------------
load("SGB12.rda")
levels(SGB12$sex) <- c("Female", "Male")
SGB12$smoking <- as.ordered(SGB12$smoking_t)
SGB12$smoking_t <- NULL


## ----SGB-setup-panel, echo = FALSE, results = "hide"---------------------
### set-up plot infrastructure
myprepanel <- function (x, y, f.value = NULL, ...) 
{
    ans <- prepanel.default.qqmath(x, f.value = f.value, distribution = qunif)
    with(ans, list(xlim = ylim, ylim = c(0, 1), dx = dy, dy = dx))
}


mypanel <- function (x, y, f.value = NULL, type = "s", groups = NULL, qtype = 7, 
    ref = TRUE, ...) 
{
    if (ref) {
        reference.line <- trellis.par.get("reference.line")
        do.call(panel.abline, c(list(h = c(0, 1)), reference.line))
    }
    x <- as.numeric(x)
    distribution <- qunif
    nobs <- sum(!is.na(x))
    if (!is.null(groups)) {
        panel.superpose(x, y = NULL, f.value = f.value, type = type, 
            distribution = distribution, qtype = qtype, groups = groups, 
            panel.groups = panel.ecdfplot, ...)
    }
    else if (nobs) {
        if (is.null(f.value)) {
            panel.xyplot(x = sort(x), y = cumsum(y[order(x)]) / sum(y),
                type = type, ...)
        }
        else {
            p <- if (is.numeric(f.value)) 
                f.value
            else f.value(nobs)
            panel.xyplot(x = quantile(x, p, names = FALSE, type = qtype, 
                na.rm = TRUE), y = distribution(p), type = type, 
                ...)
        }
    }
}

### set-up plot function for unconditional BMI models
plotfun0 <- function(prob, data, ...) {
    fm <- as.formula(paste(prob, "~ bmi"))
    xyplot(fm, data = data, type = "l", 
        key = simpleKey(c("ECDF", "Transformation Model"), points = FALSE, 
                        lines = FALSE, col = cols[1:2], lwd = 3, lty = 1:2),
        panel = function(x, y, ...) {
            mypanel(SGB12$bmi, SGB12$wght, lwd = 3, col = cols[1])
            panel.xyplot(x, y, ..., lty = 2)
    }, col = cols[2], xlab = "BMI", ylab = expression(F[Y](BMI)), lwd = 4, ...)
}


## ----tram----------------------------------------------------------------
library("tram")


## ----BMI-0-Lm, cache = TRUE----------------------------------------------
logLik(mLm <- Lm(bmi ~ 1, data = SGB12, weights = wght))
(cf <- coef(as.mlt(mLm)))
-cf[1] / cf[2]
weighted.mean(SGB12$bmi, SGB12$wght)


## ----BMI-0-Lm-plot, echo = FALSE, cache = TRUE---------------------------
nd <- expand.grid(bmi = b <- 150:400 / 10)
m0 <- Lm(bmi ~ 1, data = SGB12, weights = wght)
nd$probLm <- predict(as.mlt(m0), newdata = nd, type = "distribution")
plotfun0("probLm", nd)


## ----BMI-0-BC, cache = TRUE----------------------------------------------
logLik(mBC <- BoxCox(bmi ~ 1, data = SGB12, weights = wght))
coef(as.mlt(mBC))


## ----BMI-0-basis, echo = FALSE, fig.height = 4.5-------------------------
layout(matrix(1:2, nrow = 1))
s <- support(attr(mBC$model$bases$response, "variable"))$bmi
b <- seq(from = s[1], to = s[2], length.out = 100)
am <- model.matrix(as.mlt(mBC)$model, data = data.frame(bmi = b))
clr <- rgb(.1, .1, .1, .4)
plot(b, am[,1], ylim = range(am), xlab = "BMI", ylab = expression(a), type = "n")
tmp <- apply(am, 2, lines, x = b, col = clr, lwd = 2)
amb <- t(t(am) * coef(as.mlt(mBC)))
plot(b, amb[,1], ylim = range(amb), xlab = "BMI", ylab = expression(a * vartheta), type = "n")
tmp <- apply(amb, 2, lines, x = b, col = clr, lwd = 2)


## ----BMI-0-BC-plot, echo = FALSE-----------------------------------------
nd$probBC <- predict(as.mlt(mBC), newdata = nd, type = "distribution")
plotfun0("probBC", nd)


## ----BMI-0-BC-Lm-trafo, echo = FALSE-------------------------------------
plot(as.mlt(mBC), newdata = data.frame(1), type = "trafo", 
     col = cols[1], xlab = "BMI", ylab = "h", K = 200, lwd = 2)
plot(as.mlt(mLm), newdata = data.frame(1), type = "trafo", 
     add = TRUE, col = cols[2], K = 200, lwd = 2)
legend("bottomright", lty = 1, col = cols[1:2], 
       legend = c("BoxCox()", "Lm()"), bty = "n")


## ----BMI-0-BC-dens, echo = FALSE-----------------------------------------
plot(as.mlt(mBC), newdata = data.frame(1), type = "density", lwd = 2,
     col = cols[1], xlab = "BMI", ylab = expression(f[Y]), K = 200)
plot(as.mlt(mLm), newdata = data.frame(1), type = "density", lwd = 2,
     add = TRUE, col = cols[2], K = 200)
legend("topright", lty = 1, col = cols[1:2], 
       legend = c("BoxCox()", "Lm()"), bty = "n")


## ----BMI-0-link, cache = TRUE--------------------------------------------
logLik(mLm)
logLik(BoxCox(bmi ~ 1, data = SGB12, weights = wght, order = 25))
logLik(Coxph(bmi ~ 1, data = SGB12, weights = wght, order = 25))
logLik(Colr(bmi ~ 1, data = SGB12, weights = wght, order = 25))
logLik(Lehmann(bmi ~ 1, data = SGB12, weights = wght, order = 25))


## ----BMI-O-Polr, cache = TRUE--------------------------------------------
cumsum(prop.table(xtabs(wght ~ bmiWHO, data = SGB12)))
mP <- Polr(bmiWHO ~ 1, data = SGB12, weights = wght)
plogis(coef(as.mlt(mP)))
predict(mBC, newdata = data.frame(bmi = c(18.5, 25, 30)), 
        type = "distribution")


## ----BMI, echo = FALSE---------------------------------------------------
print(xyplot(wght~bmi, data = SGB12, col = cols, groups = sex, lwd = 3, xlab = "BMI", 
       panel = mypanel, prepanel = myprepanel, ylab = expression(F[Y](BMI)), key =
simpleKey(paste("ECDF", levels(SGB12$sex)), points = FALSE, lines = FALSE, col = cols)))



## ----BMI-1-BC, cache = TRUE----------------------------------------------
logLik(m1BC <- BoxCox(bmi ~ sex, data = SGB12, weights = wght))
coef(m1BC)
confint(m1BC)


## ----BMI-1-BC-plot, echo = FALSE, cache = TRUE---------------------------
### set-up grid
b <- 150:400 / 10
sm <- sort(unique(SGB12$smoking))
se <- sort(unique(SGB12$sex))
nd <- expand.grid(bmi = b, sex = se)

tkey <- simpleKey(levels(SGB12$sex), points = FALSE, lines = FALSE, col = cols)

plotfun <- function(prob, data, ...) {
    fm <- as.formula(paste(prob, "~ bmi"))
    xyplot(fm, data = data, type = "l", key = tkey,
        panel = function(x, y, ...) {
            tmp <- subset(SGB12, sex == "Female")
            mypanel(tmp$bmi, tmp$wght, lwd = 3, col = cols[1])
            tmp <- subset(SGB12, sex != "Female")
            mypanel(tmp$bmi, tmp$wght, lwd = 3, col = cols[2])
            panel.xyplot(x, y, ..., lty = 2)
    }, col = cols,  groups = sex, xlab = "BMI", ylab = expression(F[Y](BMI)), lwd = 2, ...)
}

nd$prob1 <- predict(as.mlt(m1BC), newdata = nd, type = "distribution")
plotfun("prob1", nd)#, main = "lm constant var")


## ----BMI-1-Lm, cache = TRUE----------------------------------------------
logLik(m1Lm <- Lm(bmi ~ sex, data = SGB12, weights = wght))
coef(m1Lm)
confint(m1Lm)


## ----BMI-1-Lm-int--------------------------------------------------------
(mcf <- coef(m1Lm) / coef(as.mlt(m1Lm))["bmi"])
coef(lm(bmi ~ sex, data = SGB12, weights = wght))


## ----BMI-1-Lm-plot, echo = FALSE-----------------------------------------
nd$prob2 <- predict(as.mlt(m1Lm), newdata = nd, type = "distribution")
plotfun("prob2", nd)#, main = "lm constant var")


## ----BMI-1-Colr, cache = TRUE--------------------------------------------
logLik(m1C <- Colr(bmi ~ sex, data = SGB12, weights = wght))
c(coef(m1C), confint(m1C))
exp(c(coef(m1C), confint(m1C)))


## ----BMI-1-Colr-plot, echo = FALSE---------------------------------------
nd$prob2 <- predict(as.mlt(m1C), newdata = nd, type = "distribution")
plotfun("prob2", nd)#, main = "lm constant var")


## ----BMI-logOR, echo = FALSE---------------------------------------------
nd$odds2 <- predict(as.mlt(m1C), newdata = nd)
print(xyplot(odds2 ~ bmi, data = nd, type = "l", 
    col = cols,  groups = sex, xlab = "BMI", ylab = expression(log(O[Y](BMI))), lwd = 2))


## ----BMI-glm, echo = FALSE, fig.width=10, cache = TRUE-------------------
b <- 120:400 / 10

m0 <- as.mlt(Colr(bmi ~ sex, data = SGB12, weights = wght))
nd <- expand.grid(bmi = b, sex = sort(unique(SGB12$sex)))
nd$p <- predict(m0, newdata = nd, type = "distribution")
nd$h <- predict(m0, newdata = nd)

b25 <- which(nd$bmi == 25)
b185 <- which(nd$bmi == 18.5)
b30 <- which(nd$bmi == 30)

layout(matrix(1:2, ncol = 2))
fm <- nd$sex == "Female"

plot(nd$bmi[fm], nd$h[fm], type = "l", col = cols[1], xlab = "BMI", 
     ylab = expression(h(y) + beta * I(male)))
abline(v = 25, col = "grey")
lines(nd$bmi[!fm], nd$h[!fm], col = cols[2])
points(nd$bmi[b25], nd$h[b25], col = cols, pch = 19)
text(nd$bmi[fm][b25] - 3.5, nd$h[fm][b25], expression(h(y[1]) == vartheta[1]))
text(nd$bmi[!fm][b25] + 3, nd$h[!fm][b25], expression(vartheta[1] + beta))

plot(nd$bmi[fm], nd$p[fm], type = "l", col = cols[1], xlab = "BMI", ylab = expression(F[Y](y)))
abline(v = 25, col = "grey")
lines(nd$bmi[!fm], nd$p[!fm], col = cols[2])
points(nd$bmi[b25], nd$p[b25], col = cols, pch = 19)
text(nd$bmi[fm][b25] - 3, nd$p[fm][b25], expression(expit(vartheta[1])))
text(nd$bmi[!fm][b25] + 4, nd$p[!fm][b25], expression(expit(vartheta[1] + beta)))


## ----BMI-polr, echo = FALSE, fig.width=10, cache = FALSE-----------------
layout(matrix(1:2, ncol = 2))
plot(nd$bmi[fm], nd$h[fm], type = "l", col = cols[1], xlab = "BMI", 
     ylab = expression(h(y) + beta * I(male)))
abline(v = c(18.5, 25, 30), col = "grey")
lines(nd$bmi[!fm], nd$h[!fm], col = cols[2])
i <- 1
for (b in list(b185, b25, b30)) {
  points(nd$bmi[b], nd$h[b], col = cols, pch = 19)
  text(nd$bmi[fm][b] - 3.5, nd$h[fm][b], bquote(h(y[.(i)]) == vartheta[.(i)]))
  text(nd$bmi[!fm][b] + 3, nd$h[!fm][b], bquote(vartheta[.(i)] + beta))
  i <- i + 1
}

plot(nd$bmi[fm], nd$p[fm], type = "l", col = cols[1], xlab = "BMI", ylab = expression(F[Y](y)))
abline(v = c(18.5, 25, 30), col = "grey")
lines(nd$bmi[!fm], nd$p[!fm], col = cols[2])
i <- 1
for (b in list(b185, b25, b30)) {
  points(nd$bmi[b], nd$p[b], col = cols, pch = 19)
  text(nd$bmi[fm][b] - 3, nd$p[fm][b], bquote(expit(vartheta[.(i)])))
  text(nd$bmi[!fm][b] + 4, nd$p[!fm][b], bquote(expit(vartheta[.(i)] + beta)))
  i <- i + 1
}


## ----BMI-1-Colr-glm-Polr, warning = FALSE, message = FALSE, cache = TRUE----
exp(c(coef(m1C), confint(m1C)))
library("MASS")
m1P <- polr(bmiWHO ~ sex, data = SGB12, weights = wght)
exp(-c(coef(m1P), confint(m1P)))
m1L <- glm(I(bmi < 25) ~ sex, data = SGB12, weights = wght, family = binomial())
exp(c(coef(m1L)["sexMale"], confint(m1L)["sexMale",]))


## ----BMI-1-Coxph, cache = TRUE-------------------------------------------
logLik(m1Cx <- Coxph(bmi ~ sex, data = SGB12, weights = wght))
exp(c(coef(m1Cx), confint(m1Cx)))


## ----BMI-1-Coxph-plot, echo = FALSE--------------------------------------
nd$prob2 <- predict(as.mlt(m1Cx), newdata = nd, type = "distribution")
plotfun("prob2", nd)#, main = "lm constant var")


## ----BMI-1-Lehmann, cache = TRUE-----------------------------------------
logLik(m1L <- Lehmann(bmi ~ sex, data = SGB12, weights = wght))
exp(-c(coef(m1L), confint(m1L)))


## ----BMI-1-Lehmann-plot, echo = FALSE------------------------------------
nd$prob2 <- predict(as.mlt(m1L), newdata = nd, type = "distribution")
plotfun("prob2", nd)#, main = "lm constant var")


## ----BMI-1-Lehmann-2, cache = TRUE---------------------------------------
logLik(m1Ls <- Lehmann(bmi | 0 + sex ~ 1, data = SGB12, weights = wght))
coef(as.mlt(m1Ls))


## ----BMI-1-Lehmann-2-plot, echo = FALSE----------------------------------
nd$prob2 <- predict(as.mlt(m1Ls), newdata = nd, type = "distribution")
plotfun("prob2", nd)#, main = "lm constant var")


## ----BMI-Stratification, cache = TRUE------------------------------------
logLik(m1Ls)
logLik(m2Ls <- Lehmann(bmi | sex ~ 1, data = SGB12, weights = wght))
cbind(coef(as.mlt(m2Ls)), confint(as.mlt(m2Ls)))


## ----BMI-ltm, cache = TRUE, warning = FALSE------------------------------
SGB12$age <- as.double(SGB12$age)
(cic <- confint(m1Lsa <- Lehmann(bmi | sex ~ age, 
                                 data = SGB12, weights = wght)))
(cii <- confint(m2Lsa <- Lehmann(bmi | sex ~ age:sex, 
                                 data = SGB12, weights = wght)))


## ----BMI-age-plot-1, echo = FALSE, fig.width = 6, fig.height = 4.5-------
layout(matrix(1:2, nrow = 1))
nda <- expand.grid(sex = sort(unique(SGB12$sex)),
                   age = 2:7 * 10)
plot(as.mlt(m1Lsa), newdata = subset(nda, sex == "Female"), 
     type = "distribution", q = 15:40, lty = 1:6, col = cols[1], 
     main = "Female", xlab = "BMI")
legend("bottomright", lty = 1:6, legend = paste("Age", 2:7*10), bty = "n")
plot(as.mlt(m1Lsa), newdata = subset(nda, sex == "Male"), 
     type = "distribution", q = 15:40, lty = 1:6, col = cols[2], 
     main = "Male", xlab = "BMI")


## ----BMI-DR, cache = TRUE, warning = FALSE-------------------------------
m3Lsa <- Lehmann(bmi | sex + age ~ 1, data = SGB12, weights = wght)
m4Lsa <- Lehmann(bmi | sex * age ~ 1, data = SGB12, weights = wght)


## ----BMI-DR-plot, echo = FALSE, fig.width = 6, fig.height = 4.5----------
nda <- expand.grid(sex = sort(unique(SGB12$sex)),
                   age = 1)
layout(matrix(1:2, nrow = 1))
i <- grep("age", names(coef(as.mlt(m3Lsa))))
tmp <- as.mlt(m3Lsa)
coef(tmp)[-i] <- 0
plot(tmp, newdata = nda[1,], type = "trafo", col = "black",
     ylab = expression(beta[Age](BMI)), xlab = "BMI")
abline(h = -cic)

i <- grep("age", names(coef(as.mlt(m4Lsa))))
tmp <- as.mlt(m4Lsa)
coef(tmp)[-i] <- 0
plot(tmp, newdata = nda, type = "trafo", col = cols,
     ylab = expression(beta[Age](BMI)), xlab = "BMI")
abline(h = -cii, col = cols)
legend("topright", legend = levels(nda$sex), lty = 1, col = cols, bty = "n")


## ----BMI-age-plot-3, echo = FALSE, fig.width = 6, fig.height = 4.5-------
layout(matrix(1:2, nrow = 1))
nda <- expand.grid(sex = sort(unique(SGB12$sex)),
                   age = 2:7 * 10)
plot(as.mlt(m3Lsa), newdata = subset(nda, sex == "Female"), 
     type = "distribution", q = 15:40, lty = 1:6, col = cols[1], 
     main = "Female", xlab = "BMI")
legend("bottomright", lty = 1:6, legend = paste("Age", 2:7*10), bty = "n")
plot(as.mlt(m3Lsa), newdata = subset(nda, sex == "Male"), 
     type = "distribution", q = 15:40, lty = 1:6, col = cols[2], 
     main = "Male", xlab = "BMI")


## ----BMI-age, cache = TRUE-----------------------------------------------
vbmi <- numeric_var("bmi", bounds = c(0, Inf), support = c(17, 35))
vage <- numeric_var("age", bounds = c(0, Inf), support = c(18, 80))
bbmi <- Bernstein_basis(vbmi, order = 5, ui = "increasing")
bage <- Bernstein_basis(vage, order = 5)
bsex <- as.basis(~ 0 + sex, data = SGB12)
m <- ctm(response = bbmi, interacting = b(age = bage, sex = bsex),
         todistr = "MaxExtrVal")
logLik(m5Lsa <- mlt(m, data = SGB12, weights = SGB12$wght))


## ----BMI-age-plot-5, echo = FALSE, fig.width = 6, fig.height = 4.5-------
layout(matrix(1:2, nrow = 1))
nda <- expand.grid(sex = sort(unique(SGB12$sex)),
                   age = 2:7 * 10)
plot(as.mlt(m5Lsa), newdata = subset(nda, sex == "Female"), 
     type = "distribution", q = 15:40, lty = 1:6, col = cols[1], 
     main = "Female", xlab = "BMI")
legend("bottomright", lty = 1:6, legend = paste("Age", 2:7*10), bty = "n")
plot(as.mlt(m5Lsa), newdata = subset(nda, sex == "Male"), 
     type = "distribution", q = 15:40, lty = 1:6, col = cols[2], 
     main = "Male", xlab = "BMI")


## ----BMI-pb--------------------------------------------------------------
simulate(m5Lsa, newdata = nda, nsim = 4)


## ----loglik-interval-1, dev='png', echo = FALSE, res = 300, fig.width=10----
y <- 0:100 / 10
layout(matrix(1:2, ncol = 2))
plot(y, pchisq(y, df = 3), type = "l", ylab = "Likelihood")
abline(v = c(3, 4), col = "grey")
abline(h = pchisq(c(3, 4), df = 3), col = "grey")
text(c(2.5, 4.5), .05, c(expression(underline(y)), expression(bar(y))))
text(.5, pchisq(3.5, df = 3), expression(L))
plot(y, dchisq(y, df = 3), type = "l", ylab = "Density")
abline(v = c(3, 4), col = "grey")
text(c(2.5, 4.5), .05, c(expression(underline(y)), expression(bar(y))))
text(3.5, .05, expression(L))


## ----BMI-1-Lehmann-logLik------------------------------------------------
logLik(m1L)
logLik(m1L, newdata = SGB12[1:10,])
(cf <- coef(as.mlt(m1L)))
cf["sexMale"] <- 0
logLik(m1L, parm = cf)
logLik(m1L, w = runif(nrow(SGB12)))


## ----BMI-1-Lehmann-methods-----------------------------------------------
head(vcov(as.mlt(m1L)), 4)
head(estfun(m1L), 4)


## ----BMI-1-Lehmann-summary-----------------------------------------------
summary(m1L)


## ----BMI-1-predict-------------------------------------------------------
nd <- expand.grid(sex = factor(c("Female", "Male")), bmi = c(18.5, 25, 30))
predict(m1Ls, newdata = nd, type = "distribution")
predict(m1Ls, newdata = nd, type = "density")
predict(m1Ls, newdata = nd, type = "hazard")
predict(m1Ls, newdata = nd[1:2,], type = "quantile", prob = 1:3 / 4)


## ----BMI-QQ, echo = FALSE, fig.width=12, fig.height=7, cache = TRUE, dev = "png"----
layout(matrix(1:2, ncol = 2))
QQcol <- rgb(.1, .1, .1, .01)
m0 <- Colr(bmi ~ sex, data = SGB12, weights = wght, order = order)
plot(m0, which = "QQ-PIT", main = "Colr()", col = QQcol, cex = sqrt(SGB12$wght) / 20, pch = 19)
m0 <- Lehmann(bmi ~ sex, data = SGB12, weights = wght, order = order)
plot(m0, which = "QQ-PIT", main = "Lehmann()", col = QQcol, cex = sqrt(SGB12$wght) / 20, pch = 19)


## ----tram-resid, eval = FALSE--------------------------------------------
## ### proportional odds alternatives (Wilcoxon)
## resid(Colr(...))
## ### proportional hazards alternatives (Log-rank)
## resid(Coxph(...))
## ### shift alternatives (van der Waerden)
## resid(BoxCox(...))


## ----CAO-setup, echo = FALSE, results = "hide", message = FALSE----------
dir <- system.file("rda", package = "TH.data")
load(file.path(dir, "Primary_endpoint_data.rda"))
### remove date variables
CAOsurv <- CAOsurv[,!sapply(CAOsurv, function(x) inherits(x, "POSIXlt"))]

ra <- sort(unique(CAOsurv$randarm))
st <- sort(unique(CAOsurv$strat_t))
sn <- sort(unique(CAOsurv$strat_n))

CAOsurv$ECOG <- factor(CAOsurv$ecog_b != levels(CAOsurv$ecog_b)[1], labels = c("0", "1-2"))
levels(CAOsurv$bentf) <- c("0-5 cm", ">5 - 10 cm", "> 10 cm")
CAOsurv$gesamt_t <- CAOsurv$gesamt_t[, drop = TRUE]
lev <- levels(CAOsurv$gesamt_t)
lev[c(grep("T2", lev), grep("T3", lev))] <- "cT2-3"
levels(CAOsurv$gesamt_t) <- lev
CAOsurv$gesamt_n_col <- CAOsurv$gesamt_n_col[, drop = TRUE]
CAOsurv$pT <- CAOsurv$pT[, drop = TRUE]
levels(CAOsurv$pT) <- c("ypT0", "ypTis/T1", "ypT2",  "ypT3",  "ypT4",  "ypT1is")
CAOsurv$pN <- CAOsurv$pN[, drop = TRUE]
### localRclass
levels(CAOsurv$path_stad) <- c("Stadium I", "Stadium II", "Stadium II", "Stadium III", "Stadium III",
                               "Stadium III", "Stadium IV",  "ypT0N0", "Stadium I")
CAOsurv$path_stad[CAOsurv$path_stad == "Stadium IV"] <- NA
CAOsurv$path_stad <- CAOsurv$path_stad[, drop = TRUE]
CAOsurv$path_stad <- relevel(CAOsurv$path_stad, "ypT0N0")
levels(CAOsurv$op_meth)[1:2] <- c("anteriore Res.", "anteriore Res.")
CAOsurv$op_meth[CAOsurv$op_meth == "andere"] <- NA
CAOsurv$op_meth <- CAOsurv$op_meth[, drop = TRUE]


## ----CAO-turnbull-1, echo = FALSE, results = "hide", cache = TRUE--------
nd <- data.frame(randarm = ra)
q <- seq(0, 2000, length.out = 100)
nd_m_r <- nd[rep(1:nrow(nd), each = length(q)),,drop = FALSE]
nd_m_r$q <- q

sf <- survfit(iDFS ~ randarm, data = CAOsurv)
s <- summary(sf, times = q)
nd_m_r$s2 <- s$surv


## ----cao-turnbull-plot, echo = FALSE, fig.width=4, fig.height=3----------
print(xyplot(s2 ~ q, data = nd_m_r, groups = randarm, type = "S", col = cols,
       ylim = c(0, 1), xlab = "Time (in days)", ylab = "Probability",
       key = simpleKey(levels(nd_m_r$randarm), col = cols, points = FALSE)))


## ----CAO-Coxph, echo = TRUE, cache = TRUE--------------------------------
logLik(m1Cx <- Coxph(iDFS ~ randarm, data = CAOsurv, log_first = TRUE))
exp(c(coef(m1Cx), confint(m1Cx)))


## ----CAO-Survreg, echo = TRUE, cache = TRUE------------------------------
logLik(mC <- Coxph(iDFS ~ randarm, data = CAOsurv, log_first = TRUE, order = 1))
logLik(mS <- Survreg(iDFS ~ randarm, data = CAOsurv))
logLik(survival::survreg(iDFS ~ randarm, data = CAOsurv))


## ----CAO-Survreg-Coxph, echo = FALSE, fig.width=4, fig.height =4---------
plot(as.mlt(m1Cx), newdata = data.frame(randarm = ra),
     type = "trafo", col = cols, ylab = "Log-cumulative hazard", 
     xlab = "Time (in days)")
plot(as.mlt(mS), newdata = data.frame(randarm = ra),
     type = "trafo", col = cols, add = TRUE, lty = 2)
legend("bottomright", legend = c("Cox 5-FU", "Cox 5-FU + OX", 
       "Weibull 5-FU", "Weibull 5-FU + OX"), lty = c(1, 1, 2, 2),
       col = rep(cols, 2), bty = "n")


## ----CAO-Coxph-coin, message = FALSE, cache = TRUE-----------------------
CAOsurv$sc <- resid(Coxph(iDFS ~ 1, data = CAOsurv, log_first = TRUE))
library("coin")
pvalue(independence_test(sc ~ randarm, data = CAOsurv, 
                         distribution = approximate(1e6)))
library("interval")
ictest(iDFS ~ randarm, data = CAOsurv, 
       method = "exact.mc")$p.values["p.twosided"]


## ----CAO-Coxph-coin-strata, message = FALSE, cache = TRUE----------------
CAOsurv$stra <- with(CAOsurv, interaction(strat_t, strat_n))
CAOsurv$scs <- resid(Coxph(iDFS | 0 + stra ~ 1, 
                     data = CAOsurv, log_first = TRUE))
independence_test(scs ~ randarm | stra, data = CAOsurv, 
                  distribution = approximate(1e6))


## ----CAO-CoxphS, message = FALSE, cache = TRUE---------------------------
(m2Cx <- Coxph(iDFS | 0 + stra ~ randarm, data = CAOsurv, log_first = TRUE))


## ----CAO-CoxphS-age-prog, cache = TRUE-----------------------------------
CAOsurv$sc_prog <- resid(m2Cx)
maxstat_test(sc_prog ~ age | stra, data = CAOsurv)


## ----CAO-CoxphS-age-prog-plot, echo = FALSE------------------------------
xyplot(sc_prog ~ age | stra, data = CAOsurv, groups = randarm, pch = 19, col = cols)


## ----CAO-CoxphS-age-pred, cache = TRUE-----------------------------------
CAOsurv$sc_pred <- estfun(m2Cx)[, "randarm5-FU + Oxaliplatin"]
maxstat_test(sc_pred ~ age | stra, data = CAOsurv)


## ----CAO-CoxphS-age-pred-mod, echo = TRUE, message = FALSE, cache = TRUE----
CAOsurv$age69 <- with(CAOsurv, cut(age, breaks = c(0, 69, 100)))
coef(m3Cx <- Coxph(iDFS | 0 + stra ~ randarm*age69, data = CAOsurv, 
                   log_first = TRUE))
K <- diag(3)[-2,]
K[2,1] <- 1
rownames(K) <- paste(names(coef(m3Cx))[1], c(" <= 69", " > 69"))
library("multcomp")
round(exp(confint(glht(m3Cx, linfct = K))$confint), 4)


## ----CAO-tree, message = FALSE, cache = TRUE-----------------------------
library("trtf")
fm <- iDFS | stra + randarm ~ age + geschlecht + ECOG + bentf + gesamt_t + 
      gesamt_n_col + pT + localRclass + path_stad + op_meth
m <- Survreg(iDFS | 0 + stra ~ randarm, data = CAOsurv)
tr <- trafotree(m, formula = fm, data = CAOsurv)
logLik(tr)


## ----CAO-tree-plot, echo = FALSE, fig.width = 10, fig.height = 6---------
nd <- expand.grid(randarm = ra, stra = sort(unique(CAOsurv$stra)))
plot(tr, newdata = nd, 
     tp_args = list(type = "survivor", col = rep(cols, 4), lwd = 2))


## ----CAO-forest, message = FALSE, cache = TRUE---------------------------
tf <- traforest(m, formula = fm, data = CAOsurv,
                control = ctree_control(maxdepth = 5))
# logLik(tf)


## ----CAO-tree-forest, message = FALSE, cache = FALSE, warning = FALSE----
coef(tr)[, "randarm5-FU + Oxaliplatin"]
sapply(predict(tf, newdata = CAOsurv[1:10,], mnewdata = CAOsurv[1:10,],
        type = "coef"), function(x) x["randarm5-FU + Oxaliplatin"])


## ----CAO-glmboost-pkg, message = FALSE, warning = FALSE------------------
library("tbm")
library("mboost")

## ----CAO-glmboost, message = FALSE, warning = FALSE, cache = TRUE, results = "hide"----
fm <- iDFS ~ bols(age, intercept = FALSE) + 
             bols(geschlecht, intercept = FALSE) + 
             bols(ECOG, intercept = FALSE) + 
             bols(bentf, intercept = FALSE) + 
             bols(gesamt_t, intercept = FALSE) + 
             bols(gesamt_n_col, intercept = FALSE) + 
             bols(pT, intercept = FALSE) + 
             bols(localRclass, intercept = FALSE) + 
             bols(path_stad, intercept = FALSE) + 
             bols(op_meth, intercept = FALSE)
cc <- complete.cases(CAOsurv[, all.vars(fm)])
m <- as.mlt(Coxph(iDFS ~ randarm, data = CAOsurv[cc,], log_first = TRUE, 
                  order = 1))
stm <- stmboost(m,
                formula = fm, data = CAOsurv[cc,all.vars(fm)],
                method = quote(mboost::mboost), 
                control = boost_control(mstop = 250, nu = .2))
stmll <- cvrisk(stm)


## ----CAO-glmboost-plot---------------------------------------------------
plot(stmll)


## ----CAO-glmboost-res----------------------------------------------------
table(variable.names(stm)[selected(stm)])
logLik(stm)
nuisance(stm)


## ----CAO-ctmboost, cache = TRUE, warning = FALSE-------------------------
m <- as.mlt(Coxph(iDFS ~ 1, data = CAOsurv[cc,], log_first = TRUE, order = 1))
ctm <- ctmboost(m,
                formula = fm, data = CAOsurv[cc,all.vars(fm)],
                method = quote(mboost::mboost), 
                control = boost_control(mstop = 250, nu = .2))
ctmll <- cvrisk(ctm)
logLik(ctm[mstop(ctmll)])
table(variable.names(ctm)[selected(ctm)])

